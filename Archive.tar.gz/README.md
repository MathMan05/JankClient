# JankClient
A SpaceBar Client written in JS HTML and CSS  
To run, clone the repo and do `npm install express`, then either  
`node index.js`
or
`bun index.js`  
Both bun and node are supported, and both should function as expected. If there are any problems with Jank Client, please let me know. To access Jank Client after init simply go to http://localhost:8080/login and login with your username and password.

Guild with more info and updates:
https://dev.app.spacebar.chat/invite/WOVGtp

Please report bugs either here or in the guild provided, thank you.

I'm new to git/github, so please be patient with me, it's my first time. if there's anything about this repo that's incorrect, please add an issue telling me what it is, or make a merge fixing it
